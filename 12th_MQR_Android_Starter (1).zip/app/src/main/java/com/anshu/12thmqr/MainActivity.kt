package com.anshu.`12thmqr`

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

/**
 * Starter UI. Server-side Firestore rules must enforce owner permissions;
 * hiding admin buttons in the UI is not security.
 */
class MainActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun makeRoot(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(android.graphics.Color.rgb(5, 13, 29))
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 28f
            setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }
        root.addView(heading)
        setContentView(root)
    }

    private fun addText(text: String, size: Float = 16f) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, 8, 0, 8)
        })
    }

    private fun field(hintText: String, secret: Boolean = false): EditText {
        return EditText(this).also {
            it.hint = hintText
            it.setSingleLine(true)
            if (secret) it.inputType = 129
            root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun button(label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }

    private fun showLogin() {
        makeRoot("12th MQR")
        addText("Practice • Improve • Score High")
        val email = field("Login ID / email")
        val password = field("Password", true)
        button("LOGIN") {
            val e = email.text.toString().trim()
            val p = password.text.toString()
            if (e.isBlank() || p.isBlank()) {
                toast("ID aur password dono bharo.")
            } else {
                auth.signInWithEmailAndPassword(e, p)
                    .addOnSuccessListener { loadRoleAndOpen() }
                    .addOnFailureListener { toast("Login failed. ID/password check karo.") }
            }
        }
        addText("Accounts sirf owner create karega. Public sign-up disabled hai.", 13f)
    }

    private fun loadRoleAndOpen() {
        val user = auth.currentUser ?: return showLogin()
        db.collection("users").document(user.uid).get()
            .addOnSuccessListener { doc ->
                when (doc.getString("role")) {
                    "owner" -> showOwner()
                    "student" -> showStudent()
                    else -> {
                        auth.signOut()
                        toast("Account role set nahi hai. Owner se contact karo.")
                        showLogin()
                    }
                }
            }
            .addOnFailureListener { toast("Account details load nahi hue.") }
    }

    private fun showOwner() {
        makeRoot("12th MQR • Owner")
        addText("Full access: accounts aur question bank manage karo.")
        button("ADD STUDENT ACCOUNT") { showCreateStudent() }
        button("ADD MCQ QUESTION") { showAddQuestion() }
        button("VIEW QUESTION COUNT") {
            db.collection("questions").get()
                .addOnSuccessListener { toast("Total questions: ${it.size()}") }
                .addOnFailureListener { toast("Questions load nahi hue.") }
        }
        button("LOG OUT") { auth.signOut(); showLogin() }
    }

    private fun showCreateStudent() {
        makeRoot("Create student account")
        val email = field("Student email / login ID")
        val pass = field("Temporary password (8+ chars)", true)
        addText("Production version mein account creation Cloud Function se karna chahiye, taaki owner ka login session replace na ho.", 13f)
        button("SAVE ACCOUNT") {
            val e = email.text.toString().trim()
            val p = pass.text.toString()
            if (e.isBlank() || p.length < 8) {
                toast("Valid email aur kam-se-kam 8 character password chahiye.")
            } else {
                // Deliberately not creating Firebase Auth users from this client:
                // doing so would replace the currently signed-in owner's session.
                toast("Setup pending: secure Cloud Function add karni hogi.")
            }
        }
        button("BACK") { showOwner() }
    }

    private fun showAddQuestion() {
        makeRoot("Add MCQ")
        val subject = field("Subject (Physics/Chemistry/Maths/Biology)")
        val topic = field("Topic")
        val prompt = field("Question")
        val a = field("Option A")
        val b = field("Option B")
        val c = field("Option C")
        val d = field("Option D")
        val answer = field("Correct option: 0, 1, 2, or 3")
        val explanation = field("Explanation")
        button("SAVE QUESTION") {
            val idx = answer.text.toString().toIntOrNull()
            if (subject.text.isBlank() || prompt.text.isBlank() ||
                listOf(a,b,c,d).any { it.text.isBlank() } || idx !in 0..3) {
                toast("Saare fields bharo; correct option 0-3 hona chahiye.")
                return@button
            }
            val data = hashMapOf(
                "subject" to subject.text.toString().trim(),
                "topic" to topic.text.toString().trim(),
                "difficulty" to "extreme",
                "prompt" to prompt.text.toString().trim(),
                "options" to listOf(a.text.toString(), b.text.toString(), c.text.toString(), d.text.toString()),
                "correctIndex" to idx,
                "explanation" to explanation.text.toString().trim(),
                "createdAt" to System.currentTimeMillis()
            )
            db.collection("questions").add(data)
                .addOnSuccessListener { toast("Question saved."); showOwner() }
                .addOnFailureListener { toast("Save failed. Security rules check karo.") }
        }
        button("BACK") { showOwner() }
    }

    private fun showStudent() {
        makeRoot("12th MQR • Practice")
        addText("Extreme MCQ practice")
        button("START PRACTICE") {
            db.collection("questions").limit(20).get()
                .addOnSuccessListener { qs ->
                    if (qs.isEmpty) toast("Abhi question bank empty hai.")
                    else showQuestion(qs.documents.map { it.data ?: emptyMap() }, 0, 0)
                }
                .addOnFailureListener { toast("Questions load nahi hue.") }
        }
        button("LOG OUT") { auth.signOut(); showLogin() }
    }

    private fun showQuestion(items: List<Map<String, Any>>, position: Int, score: Int) {
        if (position >= items.size) {
            makeRoot("Practice result")
            addText("Score: $score / ${items.size}")
            button("HOME") { showStudent() }
            return
        }
        val q = items[position]
        makeRoot("Question ${position + 1}/${items.size}")
        addText(q["prompt"]?.toString() ?: "Question")
        val options = (q["options"] as? List<*>)?.map { it.toString() } ?: emptyList()
        val group = RadioGroup(this)
        options.forEachIndexed { i, option ->
            group.addView(RadioButton(this).apply {
                text = "${'A' + i}. $option"
                setTextColor(android.graphics.Color.WHITE)
                id = i + 1
            })
        }
        root.addView(group)
        button("SUBMIT / NEXT") {
            val selected = group.checkedRadioButtonId - 1
            val correct = (q["correctIndex"] as? Number)?.toInt() ?: -1
            if (selected < 0) toast("Ek option select karo.")
            else {
                val newScore = score + if (selected == correct) 1 else 0
                val expl = q["explanation"]?.toString().orEmpty()
                Toast.makeText(this, if (selected == correct) "Correct! $expl" else "Incorrect. $expl", Toast.LENGTH_LONG).show()
                showQuestion(items, position + 1, newScore)
            }
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
