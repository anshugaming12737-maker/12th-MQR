# 12th MQR — Android starter project

यह Android Studio के लिए एक शुरुआती Kotlin project है। इसमें Owner-only account creation, student login, MCQ bank और admin management के लिए सुरक्षित cloud backend जोड़ने की संरचना दी गई है।

## महत्वपूर्ण
- यह ZIP **source project** है, compiled APK नहीं।
- Multi-user login और owner द्वारा किसी भी डिवाइस से users/questions जोड़ने या हटाने के लिए Firebase project बनाकर `google-services.json` जोड़ना होगा।
- पहले owner account को Firebase Console/एक सुरक्षित one-time setup flow से बनाया जाना चाहिए। सामान्य sign-up स्क्रीन नहीं होनी चाहिए।
- Password को कभी plaintext में store न करें। Firebase Authentication password संभालता है।
- Owner permissions को केवल app UI से नहीं, Firestore Security Rules से enforce करना जरूरी है।
- इस starter में 500+ प्रश्नों का पूरा सत्यापित question bank शामिल नहीं है। `questions_seed.json` में नमूना schema है; वास्तविक प्रश्नों को कक्षा/बोर्ड के अनुसार जोड़ना होगा।

## Setup
1. Android Studio में इस folder को खोलें।
2. Firebase Console में Android app बनाएं, package name `com.anshu.12thmqr` रखें।
3. Authentication में Email/Password enable करें।
4. Firestore Database बनाएं।
5. Firebase का `google-services.json` `app/` folder में रखें।
6. नीचे दिए गए `firestore.rules` को review करके deploy करें।
7. `Admin bootstrap` में पहले owner UID को Firebase Console से `users/{uid}` document में role `owner` देकर बनाएं। किसी public sign-up flow से owner role न दें।
8. Build > Build APK(s) से APK बनाएं।

## Planned permissions
- Owner: users add/remove, questions add/edit/delete, subjects manage, results view.
- Student: practice, tests, own results and bookmarks.
- केवल owner ही दूसरे accounts बना सकता है; public self-registration नहीं।

## Question schema
`questions_seed.json` देखें। हर question में subject, topic, difficulty, prompt, four options, correct answer index और explanation शामिल हों।
